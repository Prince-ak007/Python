#BIKE Rental SYSTEM PROJEt

"""objective
1) display avaliable bikes 
2) request a bike for rent (100rs ==> 1 quantity)
3) give EXIT option also 
""" 

class bike:
  def __init__(self,stock):
    self.stock=stock
    
  
  def display_stock(self):
    print(f"Total avalible Stock {self.stock}")

  def request_For_bike(self,Bike_need):
    if Bike_need<0:
      print("enter the +ve number")
    elif Bike_need > self.stock:
      print("We dont have that much bikes in our stock")
      print(f"Total avalible Stock {self.stock}")
    else:
      print(f"your Total Will Be {100 * Bike_need}")
      self.bike= self.stock - Bike_need
      print(f"Total bikes avaliable now {self.bike}")

while True:
  obj=bike(100)
  uc = int(input(''' 
  1 Display stocks 
  2 rent a bike
  3 Exit
  '''))
  if uc == 1:
    obj.display_stock()  
  elif uc ==2:
    Bike_need =int(input("enter the quantity you need"))
    obj.request_For_bike(Bike_need)
  else:
    break

    
    
    
    
    
# obj=bike(100,Bike_need)
# obj.display_stock()



