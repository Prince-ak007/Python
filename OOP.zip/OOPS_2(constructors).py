# oops Methods and Constructors
# we dont need to call constructor but need to call methods through objects


class democlass:
  a = 10

  #constructor (dont need to call it)
  def __init__(self):
    print("hello there")
    print(self.a)
    print()

  def sumvalue(self):

    print(self.a
          )  #without self u cant create a variable and use it in other methods
    self.c = self.a * self.a
    print(self.c)

  def showvalue(self):
    print("hey akshay")


# if there are arguments of that function then we dont need to use self.a or self.b. however if there are no arguments or varriables then we need to use self.a and self.b .

  def argu_sum(self, a, b):
    print(a + b)

object = democlass()
print(object.a)
print()
object.sumvalue()
object.showvalue()
object.argu_sum(50, 20)



#example of constuctor 
class person:
  def __init__(self,n,o,a=None):
    print(f"the person is {n} and ")
    self.name=n
    self.occ=o
    self.age=a

  def info(self):
    print(f"{self.name} is a {self.occ}")
    print(self.age)

obj=person("akshay","engineer",27)
obj.info()