# inheritance ==> more than one class
# if i want to inherit class A's methods into class B then we will use inheritance.
#like parent to chlid

# different types of inheritance
# 1. single inheritance (class A ==> class B)
# 2. multilevel inheritance (class A ==> class B ==> class C)
# 3. multiple inheritance (Class A + Class B ==> class C)


#single Inheritance
class A:

  def displayA(self):
    print("akshay is here A")


class B(A):  # A ------> B now

  def displayB(self):
    print("akshay is here B")


obj = B()  #calling class A through object B
obj.displayA()
obj.displayB()


# multilevel Inheritance (A=> B => C)
class A:

  def displayA(self):
    print("akshay is here Akshay")


class B(A):

  def displayB(self):
    print("akshay is here B")


class C(B):

  def displayC(self):
    print("akshay is here C")


obj = C()
obj.displayA()
obj.displayB()
obj.displayC()

#Multiple Inheritance


class A:

  def displayA(self):
    print("akshay is here Sam")


class B:

  def displayB(self):
    print("akshay is here B")


class C(A, B):  # A +B ===> C

  def displayC(self):
    print("akshay is here C")


obj = C()
obj.displayA()
