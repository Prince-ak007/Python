# Encapsulation in Python
#Getter and Setter

class Student: 
  def  __init__(self):
    self.__name=""

  def getname(self):
    return self.__name

  def setname(self,name):
    self.__name=name

obj=Student()
obj.setname("Aksahy")
name=obj.getname()
print(name)




#Private variable AND FUNCTION


# Encapsulation (u can make private variable in encapsulation by using "__variable_name)
#you cant using object but u can call inside the class.

class student:
  __name="akshay"
  def __init__(self):
    print(self.__name)
    self.__display()
  def __display(self):
    print("welcome akshay")

obj=student()
