# one class can have multiple objects..
# all that stuff inside the class we call it method
#we can call variables and functions through objects (-_-)
# e.g. ===>


class person:
  name = "akshay"
  id = "1516A"

  def college(self):
    print("hey sir how it's going on")


object = person()

# call "VAriablE" through object
print(object.name)

# call "FunctioN" through object
object.college()
